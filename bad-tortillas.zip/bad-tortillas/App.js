import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';

// Componente para exibir imagens
const ImageComponent = ({ source }) => {
  return <Image source={source} style={styles.image} />;
};

// Componente para o botão
const ButtonComponent = ({ onPress, text }) => {
  return (
    <TouchableOpacity onPress={onPress} style={styles.button}>
      <Text style={styles.buttonText}>{text}</Text>
    </TouchableOpacity>
  );
};

export default function App() {
  const primeiraImagem = require('./assets/imagem1.jpg');
  const segundaImagem = require('./assets/imagem2.jpg');

  return (
    <View style={styles.container}>
      <Text style={styles.headerText}>Lionel Messi</Text>
      <ImageComponent source={primeiraImagem} />
      <ImageComponent source={segundaImagem} />
      <ButtonComponent
        text="Clique em mim"
        onPress={() => alert('Botão clicado!')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink', // Cor de fundo diferente de branco
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  image: {
    width: 200,
    height: 200,
    marginVertical: 10,
  },
  button: {
    backgroundColor: 'black',
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});